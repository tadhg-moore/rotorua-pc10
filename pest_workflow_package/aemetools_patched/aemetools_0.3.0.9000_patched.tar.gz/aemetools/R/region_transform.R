#' Per-sub-region transformation of observed and modelled values
#'
#' A calibration or sensitivity sub-region (an element of the named-list
#' `vars_sim` form accepted by [calib_aeme()], [sa_aeme()] and
#' [create_sen_control()]) may carry a `transform` element. The observed *and*
#' the modelled values of that region are put through the same transformation
#' before they are scored, so a skewed variable (blooms, suspended-solids
#' peaks) is not dominated by a few large values.
#'
#' `transform` is one of
#' * `NULL` (the default, or `"none"`): no transformation - behaviour is
#'   unchanged;
#' * a single string: `"log"`, `"log1p"`, `"log10"` or `"sqrt"`;
#' * a list `list(fun = <string>, offset = <number>)`, which transforms
#'   `fun(x + offset)` (e.g. `list(fun = "log", offset = 0.5)` for
#'   `log(x + 0.5)`, with the offset near the detection limit). `"log1p"` is
#'   `log(1 + x)` and takes no offset.
#'
#' Domain handling differs by role, on purpose. An *observation* outside the
#' function's domain (e.g. `x + offset <= 0` for `"log"`) is invalid data and
#' becomes `NA` (it is then dropped from the PEST observation table). A
#' *modelled* value outside the domain is numerical noise (e.g. a
#' concentration of `-1e-9`) and is clamped to the domain boundary, so a
#' transformed simulation is always finite and a PEST run is not failed by it.
#'
#' Applied in three places, always with the same function: the PEST
#' observation values and balancing scale ([pest_obs_table()]), the
#' modelled values and the scored data frame ([run_and_fit()], which feeds the
#' residual-mode forward run, fit mode and the non-PEST path), and the
#' per-region value `pestpp-sen` measures in a sensitivity analysis.
#'
#' @name region_transform
#' @keywords internal
#' @noRd
NULL

.transform_funs <- c("log", "log1p", "log10", "sqrt")

#' Validate a region's `transform` and return it as `list(fun, offset)`
#' (or `NULL` for none). Idempotent.
#' @param x user-supplied transform spec.
#' @param region region name, for error messages.
#' @noRd
.normalise_transform <- function(x, region = NULL) {
  if (is.null(x) || (is.character(x) && length(x) == 1 && x == "none")) {
    return(NULL)
  }
  where <- if (is.null(region)) "" else paste0(" of region ", dQuote(region, FALSE))
  if (is.character(x) && length(x) == 1) x <- list(fun = x)
  if (!is.list(x) || is.null(x$fun) || !is.character(x$fun) ||
      length(x$fun) != 1 || !x$fun %in% .transform_funs) {
    cli::cli_abort(c(
      "Invalid {.field transform}{where}.",
      "i" = "Use {.code NULL}, one of {.val {(.transform_funs)}}, or
             {.code list(fun = , offset = )}."))
  }
  offset <- if (is.null(x$offset)) 0 else x$offset
  if (!is.numeric(offset) || length(offset) != 1 || !is.finite(offset)) {
    cli::cli_abort("{.field transform$offset}{where} must be a single number.")
  }
  if (x$fun == "log1p" && offset != 0) {
    cli::cli_abort(c("{.val log1p} takes no {.field offset}{where}.",
                     "i" = "Use {.code list(fun = \"log\", offset = 1)} for
                            {.code log(1 + x)} with an offset of your own."))
  }
  if (offset < 0) {
    cli::cli_abort("{.field transform$offset}{where} must be >= 0.")
  }
  list(fun = x$fun, offset = offset)
}

#' Apply a transform to observed or modelled values
#'
#' @param x numeric values.
#' @param spec from [.normalise_transform()] (or `NULL`).
#' @param role `"obs"`: values outside the function's domain become `NA`;
#'   `"model"`: they are clamped to the domain boundary.
#' @noRd
.apply_transform <- function(x, spec, role = c("obs", "model")) {
  if (is.null(spec)) return(x)
  role <- match.arg(role)
  z <- if (spec$fun == "log1p") x else x + spec$offset
  # log: z > 0 ; log10: z > 0 ; log1p: x >= 0 (concentrations) ; sqrt: z >= 0
  lower <- if (spec$fun %in% c("log", "log10")) 1e-12 else 0
  bad <- !is.na(z) & z < lower
  if (role == "obs") {
    z[bad] <- NA_real_
  } else {
    z[bad] <- lower
  }
  switch(spec$fun,
         log = log(z), log10 = log10(z), sqrt = sqrt(z), log1p = log1p(z))
}

#' Human-readable label, e.g. `log(x + 0.5)`
#' @noRd
.transform_label <- function(spec) {
  if (is.null(spec)) return("none")
  if (spec$fun == "log1p") return("log1p(x)")
  if (spec$offset == 0) return(paste0(spec$fun, "(x)"))
  paste0(spec$fun, "(x + ", format(spec$offset), ")")
}

#' Transform the observed and modelled columns of a scored data frame for each
#' region that has a `transform` (rows identified by their `name` column).
#' Recomputes `diff`. Regions without a transform are untouched.
#' @param comp data frame with `name`, `obs`, `model` (and optionally `diff`).
#' @param regions named list of region specs (raw or normalised).
#' @noRd
.transform_region_rows <- function(comp, regions) {
  if (is.null(regions) || !"name" %in% names(comp)) return(comp)
  for (nm in names(regions)) {
    spec <- .normalise_transform(regions[[nm]]$transform, nm)
    if (is.null(spec)) next
    rows <- which(!is.na(comp$name) & comp$name == nm)
    if (length(rows) == 0) next
    if ("obs" %in% names(comp)) comp$obs[rows] <- .apply_transform(comp$obs[rows], spec, "obs")
    comp$model[rows] <- .apply_transform(comp$model[rows], spec, "model")
    if ("diff" %in% names(comp)) comp$diff[rows] <- comp$model[rows] - comp$obs[rows]
  }
  comp
}
