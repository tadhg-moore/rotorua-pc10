#' Read calibration output
#'
#' @inheritParams calib_aeme
#' @inheritParams AEME::build_aeme
#' @inheritParams read_simulation_meta
#' @param file_type string; file type to write the output to. Options are 
#' `c("csv", "db")`. Defaults to "db".
#' @param sim_id A vector of simulation IDs to read. If NULL, all simulations
#' are read.
#' @param type A character string indicating the type of simulation. One of
#' "calib", "sa", or "all". If missing, the type is inferred from the
#' `ctrl` argument. If type is provided it overrides the `ctrl$method` value.
#'
#' @importFrom dplyr case_when left_join mutate select summarise group_by
#' @importFrom tidyr pivot_longer
#' @importFrom utils read.csv
#' @importFrom stats median
#' @importFrom DBI dbConnect dbReadTable dbDisconnect
#' @importFrom duckdb duckdb
#' @importFrom tools file_ext
#' @examples
#' aeme_file <- system.file("extdata/aeme.rds", package = "AEME")
#' aeme <- readRDS(aeme_file)
#' model_controls <- AEME::get_model_controls()
#' model <- c("glm_aed", "gotm_wet")
#' path <- "aeme"
#' aeme <- AEME::build_aeme(aeme = aeme, model = model, path = path,
#'                          model_controls = model_controls, ext_elev = 5) |>
#'   AEME::run_aeme()
#' 
#' data("aeme_parameters", package = "AEME")
#' param <- aeme_parameters
#' 
#' # Function to calculate fitness (nse_loss = -1 * NSE, minimised by calib_aeme)
#' FUN_list <- list(HYD_temp = nse_loss, LKE_lvlwtr = nse_loss)
#' 
#' ctrl <- create_control(method = "calib", NP = 10, itermax = 20, ncore = 2,
#'                        parallel = TRUE, file_type = "db",
#'                        file_name = "results.db")
#' 
#' vars_sim <- c("HYD_temp", "LKE_lvlwtr")
#' weights <- c("HYD_temp" = 1, "LKE_lvlwtr" = 1)
#' 
#' # Calibrate AEME model
#' sim_id <- calib_aeme(aeme = aeme, model = model, path = path,
#'                      param = param, FUN_list = FUN_list, ctrl = ctrl,
#'                      vars_sim = vars_sim, weights = weights)
#'                      
#' # Read calibration output                      
#' calib <- read_calib(sim_id = sim_id, ctrl = ctrl)
#' @return A list with the metadata and simulation data frames.
#' @export

read_simulation_output <- function(ctrl = NULL, file_name, file_dir, 
                                   file_type = "db", sim_id = NULL, type) {

  meta_tables <- c("lake_metadata", "simulation_metadata",
                   "function_metadata", "parameter_metadata",
                   "simulation_data")
  if (!is.null(ctrl) & missing(type)) {
    type <- ctrl$method
  }
  if (!is.null(ctrl)) {
    file_dir <- ctrl$file_dir
    file_name <- ctrl$file_name
    file_type <- ctrl$file_type
  }
  
  if (type == "sa") {
    meta_tables <- c(meta_tables, "sensitivity_metadata")
    # Only a pestpp-sen run (create_sen_control()) writes solver sensitivity
    # indices, so this table may be absent for a built-in Sobol' run -
    # include it only when it exists.
    if (.has_table("sensitivity_indices", file_dir, file_name, file_type)) {
      meta_tables <- c(meta_tables, "sensitivity_indices")
    }
  } else if (type == "calib") {
    meta_tables <- c(meta_tables, "calibration_metadata")
    # Only PEST++ runs write a posterior ensemble, so this table may not
    # exist even for a calibration - include it only when it does, rather
    # than failing the read for every built-in run.
    if (.has_table("pest_posterior", file_dir, file_name, file_type)) {
      meta_tables <- c(meta_tables, "pest_posterior")
    }
  } else if (type == "all") {
    meta_tables <- c(meta_tables, "sensitivity_metadata",
                     "calibration_metadata")
  }
  names(meta_tables) <- meta_tables
  
  if (file_type == "db") {
    file <- file.path(file_dir, file_name)
  } else if (file_type == "csv") {
    file <- file.path(file_dir, paste0(meta_tables, ".csv"))
  }
  
  sim_vec <- sim_id

  if (!all(file.exists(file)) & type != "all") {
    stop("File not found: ", file)
  } else if (type == "all") {
    not_found <- !file.exists(file)
    message("File not present: ", file[not_found])
    meta_tables <- meta_tables[!not_found]
  }


  # all <- lapply(sim_id, \(sid) {
  if (file_type == "csv") {
    out <- lapply(meta_tables, function(x) {
      df <- read.csv(file.path(file_dir, paste0(x, ".csv")))
      if (!is.null(sim_id)) {
        if (x == "lake_metadata") {
          lake_id <- read.csv(file.path(file_dir, "simulation_metadata.csv")) |>
            dplyr::filter(sim_id %in% sim_vec) |>
            dplyr::pull(id)
          df <- df |>
            dplyr::filter(id %in% lake_id) |>
            as.data.frame()
        } else {
          df <- df |>
            dplyr::filter(sim_id %in% sim_vec) |>
            as.data.frame()
        }
      }
      return(df)
    })
  } else if (file_type == "db") {
    con <- DBI::dbConnect(duckdb::duckdb(), dbdir = file)
    on.exit(DBI::dbDisconnect(con, shutdown = TRUE))

    out <- lapply(meta_tables, function(x) {
      if (x == "lake_metadata" & !is.null(sim_id)) {
        lake_id <- dplyr::tbl(con, "simulation_metadata") |>
          dplyr::filter(sim_id %in% sim_vec) |>
          dplyr::pull(id)
        dplyr::tbl(con, x) |>
          dplyr::filter(id %in% lake_id) |>
          as.data.frame()
      } else {
        if (!is.null(sim_id)) {
          df <- dplyr::tbl(con, x) |>
            dplyr::filter(sim_id %in% sim_vec) |>
            as.data.frame()
        } else {
          df <- dplyr::tbl(con, x) |>
            as.data.frame()
        }
      }
    })
  }
  return(out)
}

#' Does an optional table exist in the results store?
#' @noRd
.has_table <- function(tbl, file_dir, file_name, file_type) {
  if (identical(file_type, "csv")) {
    return(file.exists(file.path(file_dir, paste0(tbl, ".csv"))))
  }
  f <- file.path(file_dir, file_name)
  if (!file.exists(f)) return(FALSE)
  con <- tryCatch(DBI::dbConnect(duckdb::duckdb(), dbdir = f, read_only = TRUE),
                  error = function(e) NULL)
  if (is.null(con)) return(FALSE)
  on.exit(DBI::dbDisconnect(con, shutdown = TRUE))
  tbl %in% DBI::dbListTables(con)
}

#' @rdname read_simulation_output
#' @export
read_calib <- read_simulation_output

