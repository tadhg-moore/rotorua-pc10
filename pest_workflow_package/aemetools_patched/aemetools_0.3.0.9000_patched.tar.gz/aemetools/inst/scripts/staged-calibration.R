# Staged calibration of GLM-AED with PEST++
# ============================================================================
#
# Calibrates a lake in three stages, each one screened with a Morris
# sensitivity analysis, localised from that screening, and solved with
# pestpp-ies:
#
#   1. water balance   -> water level
#   2. thermal structure -> temperature (+ water level)
#   3. biogeochemistry -> oxygen, ammonium, phosphorus
#
# Physics drives biogeochemistry (stratification controls oxygen and nutrient
# recycling) but barely the reverse, so fixing the water balance, then the
# thermal structure, stops nutrient errors being compensated by volume or
# mixing errors. Each stage's winners are frozen for the next.
#
# Requires PEST++: run aemetools::install_pest() once.
# Runtime on 27 cores: roughly ten minutes for a one-year simulation.

library(AEME)
library(aemetools)

stopifnot(have_pest())

# ---- configuration ---------------------------------------------------------

ROOT     <- file.path("staged-calibration")
START    <- "2016-07-01"
STOP     <- "2022-03-24"
SPIN_UP  <- 365 * 3
MODEL    <- "glm_aed"
NCORE    <- max(1L, floor(0.85 * parallel::detectCores()))  # 85% of the box
MORRIS_R <- 5      # Morris trajectories; raise for a screen you will act on
NOPTMAX  <- 10      # pestpp-ies iterations
N_REALS  <- 100     # ensemble size
THR      <- 0.10   # keep a parameter reaching 10% of the leading mu_star

dir.create(ROOT, recursive = TRUE, showWarnings = FALSE)
message("Using ", NCORE, " cores")

aeme0 <- readRDS(system.file("extdata/LID50270_Rototoa.rds",
                             package = "aemetools"))
get_calib_periods(aeme0, vars_sim = c("LKE_lvlwtr", "HYD_temp", "HYD_thmcln", "HYD_strat",
                                 "CHM_oxy", "NIT_amm", "PHS_frp", "PHY_tchla"))
aeme0 <- AEME::set_time(aeme0, start = START, stop = STOP, spin_up = SPIN_UP)

# ---- parameter helpers -----------------------------------------------------

utils::data("aeme_parameters", package = "AEME")
utils::data("aeme_parameters_bgc", package = "AEME")

PCOLS <- c("model", "file", "name", "value", "min", "max", "group", "index")
POOL <- unique(rbind(
  aeme_parameters[aeme_parameters$model == MODEL, PCOLS],
  aeme_parameters_bgc[aeme_parameters_bgc$model == MODEL, PCOLS]))

#' Shipped parameter rows, by name.
shipped <- function(nms) as.data.frame(POOL[POOL$name %in% nms, ])

#' A parameter row built from scratch, for anything the shipped tables do not
#' carry. Bounds default to +/- `fac` of the current value.
prow <- function(file, name, value, min = NULL, max = NULL, fac = 0.5,
                 group = NA_character_, index = NA_real_) {
  if (is.null(min)) min <- value - abs(value) * fac
  if (is.null(max)) max <- value + abs(value) * fac
  data.frame(model = MODEL, file = file, name = name, value = value,
             min = min, max = max, group = group, index = index,
             stringsAsFactors = FALSE)
}

#' Repeat a row once per sediment zone. Zoned parameters are written to the
#' model as an ARRAY with one value per zone: a single row where the model
#' expects three produces a short array and the model dies a few hundred
#' days in, with no warning. GLM's &sediment block and AED's sediment block
#' declare their zone counts separately and need not agree.
per_zone <- function(df, n) do.call(rbind, lapply(seq_len(n), function(i) {
  d <- df; d$index <- i; d
}))

#' Repeat a row once per phytoplankton group. For aed_phyto_pars.csv the
#' `group` column selects the column of the file and `name` selects the row.
per_phyto <- function(df, groups) do.call(rbind, lapply(groups, function(g) {
  d <- df; d$group <- g; d
}))

add_name_full <- function(p) {
  p$name_full <- encode_param(p$group, p$name, p$index)
  p
}

#' Fix a parameter: value == min == max makes calib_aeme() and sa_aeme()
#' write it to the model and drop it from the search.
freeze <- function(p) { p$min <- p$value; p$max <- p$value; p }

#' Checkpoint each stage's result to `<ROOT>/sN.rds`, so a lost session or a
#' failure in a later step can be resumed without re-running the solver.
#' `<ROOT>/sN.rds` sits outside anything fresh_build() unlink()s. The RDS
#' complements the on-disk results DB + kept PEST directory; it does not
#' replace them, and re-entry still needs this same working directory.
stage_rds <- function(n) file.path(ROOT, sprintf("s%d.rds", n))
run_or_load <- function(n, expr) {
  f <- stage_rds(n)
  if (file.exists(f)) {
    message("stage ", n, ": resumed from ", f)
    return(readRDS(f))
  }
  res <- force(expr)
  saveRDS(res, f)
  res
}

#' Build and run the model into its own directory.
#'
#' Every stage - and every step within a stage - gets a fresh build. PEST
#' staging and input_model_parameters() both rewrite the lake directory in
#' place, so re-using one leaves a configuration that is no longer the one
#' that was built.
fresh_build <- function(tag, vars_sim, use_bgc) {
  p <- file.path(ROOT, tag)
  unlink(p, recursive = TRUE)
  dir.create(p, recursive = TRUE, showWarnings = FALSE)
  mc <- AEME::set_vars_sim(AEME::get_model_controls(use_bgc = use_bgc), 
                           vars_sim = vars_sim)
  a <- AEME::build_aeme(path = p, aeme = aeme0, model = MODEL,
                        model_controls = mc, ext_elev = 5, use_bgc = use_bgc)
  a <- AEME::run_aeme(aeme = a, model = MODEL, path = p)
  list(aeme = a, path = p)
}

# ---- one stage -------------------------------------------------------------

#' Screen with Morris, select, localise, then calibrate with pestpp-ies.
#'
#' @param adjustable,frozen parameter dataframes.
#' @param targets AEME variables to calibrate against.
#' @param sub_regions named list for create_sen_control(); names must contain
#'   an underscore.
#' @param screen FALSE skips the screen - right for a handful of parameters,
#'   and required for a water-level-only stage, which the SA path cannot
#'   index (it has no gridded variable).
#' @param rebuild function returning a fresh list(aeme, path) for the
#'   calibration step.
#' @param prior_from an earlier stage's result list, or NULL. When given, its
#'   posterior ensemble seeds this stage's prior (create_pest_control's
#'   `prior_par_ensemble`): parameters shared by name come in at their
#'   posterior spread and correlations, new ones are drawn from their bounds.
#'   Strictly more information than re-opening a box of independent bounds.
run_stage <- function(stage, aeme, path, adjustable, frozen, targets,
                      sub_regions, screen = TRUE, rebuild = NULL,
                      prior_from = NULL) {

  message("\n=== stage ", stage, ": ", paste(targets, collapse = ", "), " ===")
  adj <- add_name_full(adjustable)
  fdir <- file.path(path, "calib_sa")
  keep_adj <- adj
  pvm <- NULL
  sa_id <- NA_character_
  sen <- NULL

  if (screen) {
    sen_ctrl <- create_sen_control(file_dir = fdir, morris_r = MORRIS_R,
                                   ncore = NCORE, vars_sim = sub_regions)
    mean_fit <- function(df) mean(df$model, na.rm = TRUE)
    sa_id <- unname(sa_aeme(
      aeme = aeme, model = MODEL, param = add_name_full(rbind(adj[, PCOLS],
                                                              frozen[, PCOLS])),
      FUN_list = stats::setNames(lapply(targets, function(v) mean_fit), targets),
      path = path, ctrl = sen_ctrl)[[1]])

    sen <- read_sen(ctrl = sen_ctrl, sim_id = sa_id)
    mu <- sen[[sa_id]]$indices
    mu <- mu[mu$index_type == "mu_star", ]

    # mu_star is in each sub-region's own units, so scale to its maximum
    # before comparing across sub-regions.
    mu$rel <- stats::ave(mu$value, mu$variable, FUN = function(v)
      if (max(v, na.rm = TRUE) > 0) v / max(v, na.rm = TRUE) else v * 0)
    sub_var <- vapply(sub_regions, function(x) x$var, character(1))
    mu$var_aeme <- sub_var[mu$variable]
    infl <- mu[mu$rel >= THR, ]

    # Keep zoned parameters as COMPLETE sets. Dropping the zones that did not
    # screen leaves a short array, and the model fails - so a zoned parameter
    # is kept or dropped on the strength of its most influential zone.
    keep_names <- unique(adj$name[adj$name_full %in% unique(infl$parameter)])
    keep_adj <- adj[adj$name %in% keep_names, ]
    message("  kept ", nrow(keep_adj), " of ", nrow(adj))
    if (nrow(keep_adj) == 0) stop("stage ", stage, ": nothing was sensitive")

    # Link by parameter name for the same reason: a zone re-added to complete
    # an array has no sensitivity of its own, and pestpp-ies treats an
    # unlinked parameter as fixed.
    pvm_list <- lapply(split(infl$parameter, infl$var_aeme), function(z) {
      nms <- unique(adj$name[adj$name_full %in% unique(z)])
      keep_adj$name_full[keep_adj$name %in% nms]
    })
    pvm_list <- pvm_list[vapply(pvm_list, length, integer(1)) > 0]
    pvm <- as_param_var_matrix(pvm_list, param = keep_adj, vars_sim = targets)
  }

  if (!is.null(rebuild)) {
    b <- rebuild()
    aeme <- b$aeme
    path <- b$path
    fdir <- file.path(path, "calib_sa")
  }

  prior_en <- if (is.null(prior_from)) NULL else {
    read_calib(ctrl = prior_from$cal_ctrl, sim_id = prior_from$cal_id)
  }

  cal_ctrl <- create_pest_control(
    exe = "pestpp-ies", noptmax = NOPTMAX, ies_num_reals = N_REALS,
    ncore = NCORE, file_dir = fdir, pest_dir = paste0("pest_s", stage),
    localizer = pvm, prior_par_ensemble = prior_en,
    pestpp_options = list(ies_lambda_mults = 1, lambda_scale_fac = 1))

  cal_id <- unname(calib_aeme(
    aeme = aeme, path = path,
    param = add_name_full(rbind(keep_adj[, PCOLS], frozen[, PCOLS])),
    model = MODEL, vars_sim = targets,
    FUN_list = stats::setNames(lapply(targets, function(v) kge_loss), targets),
    weights = set_weights(targets), ctrl = cal_ctrl)[[1]])

  calib <- read_calib(ctrl = cal_ctrl, sim_id = cal_id)
  phi <- read_pest_phi(calib)
  message("  phi: ", paste(signif(phi$min, 4), collapse = " -> "))

  list(stage = stage, sa_id = sa_id, cal_id = cal_id, sen = sen,
       kept = keep_adj, pvm = pvm, phi = phi, cal_ctrl = cal_ctrl,
       best = add_name_full(get_best_params(calib = calib)[, PCOLS]))
}

#' The winners of a stage, fixed for the stages that follow.
carry <- function(res, except = character()) {
  b <- res$best[res$best$name_full %in% res$kept$name_full &
                  !(res$best$name %in% except), PCOLS]
  freeze(b)
}

# ============================================================================
# Stage 1 - water balance against water level
# ============================================================================
# Four parameters: nothing to screen out, and the SA path cannot handle a
# water-level-only sub-region set, so the screen is skipped.

b1 <- fresh_build("s1", "LKE_lvlwtr", use_bgc = FALSE)
cfg <- AEME::configuration(b1$aeme)$glm_aed
n_glm_zones <- cfg$hydrodynamic$sediment$n_zones
z <- AEME::input(b1$aeme)$init_depth
sed <- cfg$hydrodynamic$sediment

s1_adj <- rbind(
  shipped(c("outflow")),
  # prow("met", "MET_pprain", 1, min = 0.7, max = 1.3),
  prow("glm4.nml", "outflow/seepage_rate", 5e-4, min = 0, max = 2e-3))

s1 <- run_or_load(1, run_stage(1, b1$aeme, b1$path, s1_adj, POOL[0, PCOLS],
                targets = "LKE_lvlwtr", sub_regions = NULL, screen = FALSE))

# ============================================================================
# Stage 2 - thermal structure against temperature and water level
# ============================================================================

vars_phys <- c("HYD_temp", "HYD_thmcln", "HYD_strat", "LKE_lvlwtr")
b2 <- fresh_build("s2", vars_phys, use_bgc = FALSE)

s2_adj <- rbind(
  shipped(c("light/Kw", "MET_radswd", "MET_wndspd",
            "mixing/coef_mix_conv", "mixing/coef_mix_hyp",
            "mixing/coef_mix_shear", "mixing/coef_mix_turb",
            "mixing/coef_wind_stir")),
  prow("glm4.nml", "mixing/coef_mix_KH", cfg$hydrodynamic$mixing$coef_mix_KH),
  prow("met", "MET_tmpair", 1, min = 0.9, max = 1.1),
  per_zone(prow("glm4.nml", "sediment/sed_temp_mean",
                mean(sed$sed_temp_mean), fac = 0.4), n_glm_zones),
  per_zone(prow("glm4.nml", "sediment/sed_temp_amplitude",
                mean(sed$sed_temp_amplitude), min = 0.1, max = 6), n_glm_zones),
  per_zone(prow("glm4.nml", "sediment/sed_heat_Ksoil",
                mean(sed$sed_heat_Ksoil), fac = 0.6), n_glm_zones),
  per_zone(prow("glm4.nml", "sediment/sed_temp_depth",
                mean(sed$sed_temp_depth), fac = 0.6), n_glm_zones))

s2 <- run_or_load(2, run_stage(
  2, b2$aeme, b2$path, s2_adj, carry(s1), targets = vars_phys,
  sub_regions = list(
    surf_temp = list(var = "HYD_temp", month = c(12, 1, 2), depth_range = c(0, 2)),
    bot_temp  = list(var = "HYD_temp", month = c(12, 1, 2), depth_range = c(z - 4, z)),
    win_temp  = list(var = "HYD_temp", month = c(6, 7, 8), depth_range = c(0, z)),
    thermo_cline = list(var = "HYD_thmcln", month = 1:12, depth_range = c(0, z)),
    start_days  = list(var = "HYD_strat", month = 1:12, depth_range = c(0, z)),
    lake_lvl  = list(var = "LKE_lvlwtr", month = 1:12, depth_range = c(0, 1))),
  rebuild = function() fresh_build("s2cal", vars_phys, use_bgc = FALSE),
  prior_from = s1))

# ============================================================================
# Stage 3 - biogeochemistry
# ============================================================================
# Water level is deliberately not a target here: use_bgc = TRUE together with
# LKE_lvlwtr returns empty variable indices. The water balance is fixed by
# stage 1 regardless.

vars_bgc <- c("CHM_oxy", "NIT_amm", "PHS_frp", "PHY_tchla")
b3 <- fresh_build("s3", vars_bgc, use_bgc = TRUE)
aeme <- AEME::run_aeme(b3$aeme)
plot_output(aeme, "tchla")
cfg3 <- AEME::configuration(b3$aeme)$glm_aed
aed <- cfg3$bgc$aed
n_aed_zones <- aed$aed_sed_const2d$n_zones
phyto <- as.data.frame(cfg3$bgc$aed_phyto_pars)
groups <- c("cyano", "green", "diatom")   # the_phytos = 2, 3, 7

pv <- function(nm, g) as.numeric(phyto[phyto$p_name == nm, g])
av <- function(mod, nm) as.numeric(aed[[mod]][[nm]][1])

s3_adj <- rbind(
  per_zone(prow("aed.nml", "aed_sed_const2d/fsed_oxy",
                av("aed_sed_const2d", "fsed_oxy"), fac = 0.5), n_aed_zones),
  per_zone(prow("aed.nml", "aed_sed_const2d/fsed_amm",
                av("aed_sed_const2d", "fsed_amm"), fac = 0.7), n_aed_zones),
  per_zone(prow("aed.nml", "aed_sed_const2d/fsed_frp",
                av("aed_sed_const2d", "fsed_frp"), fac = 0.7), n_aed_zones),
  prow("aed.nml", "aed_oxygen/fsed_oxy", av("aed_oxygen", "fsed_oxy"), fac = 0.5),
  prow("aed.nml", "aed_oxygen/ksed_oxy", av("aed_oxygen", "ksed_oxy"), fac = 0.5),
  prow("aed.nml", "aed_oxygen/theta_sed_oxy", av("aed_oxygen", "theta_sed_oxy"),
       min = 1.02, max = 1.12),
  prow("aed.nml", "aed_nitrogen/rnitrif", av("aed_nitrogen", "rnitrif"), fac = 0.6),
  prow("aed.nml", "aed_nitrogen/knitrif", av("aed_nitrogen", "knitrif"), fac = 0.5),
  prow("aed.nml", "aed_nitrogen/rdenit", av("aed_nitrogen", "rdenit"), fac = 0.6),
  prow("aed.nml", "aed_nitrogen/kdenit", av("aed_nitrogen", "kdenit"), fac = 0.5),
  prow("aed.nml", "aed_nitrogen/ksed_amm", av("aed_nitrogen", "ksed_amm"), fac = 0.5),
  prow("aed.nml", "aed_phosphorus/ksed_frp", av("aed_phosphorus", "ksed_frp"), fac = 0.5),
  prow("aed.nml", "aed_phosphorus/theta_sed_frp",
       av("aed_phosphorus", "theta_sed_frp"), min = 1.02, max = 1.12),
  prow("aed.nml", "aed_organic_matter/rdom_minerl",
       av("aed_organic_matter", "rdom_minerl"), fac = 0.7),
  prow("aed.nml", "aed_organic_matter/kpom_hydrol",
       av("aed_organic_matter", "kpom_hydrol"), fac = 0.5),
  prow("aed.nml", "aed_organic_matter/kdom_minerl",
       av("aed_organic_matter", "kdom_minerl"), fac = 0.5),
  prow("aed.nml", "aed_organic_matter/fsed_doc",
       av("aed_organic_matter", "fsed_doc"), fac = 0.7),
  # Phytoplankton, per group. These need a chlorophyll target to be
  # identifiable - with oxygen and nutrients alone the screen drops them all.
  per_phyto(prow("aed_phyto_pars.csv", "R_growth", pv("R_growth", "cyano"),
                 fac = 0.5), groups),
  per_phyto(prow("aed_phyto_pars.csv", "I_K", pv("I_K", "cyano"), fac = 0.6),
            groups),
  per_phyto(prow("aed_phyto_pars.csv", "K_N", pv("K_N", "cyano"), fac = 0.6),
            groups),
  per_phyto(prow("aed_phyto_pars.csv", "K_P", pv("K_P", "cyano"), fac = 0.6),
            groups),
  per_phyto(prow("aed_phyto_pars.csv", "R_resp", pv("R_resp", "cyano"),
                 fac = 0.6), groups),
  # Light attenuation re-opened, bounded by the stage-2 posterior: it is the
  # one place the thermal and biogeochemical calibrations genuinely meet.
  s2$best[s2$best$name == "light/Kw", PCOLS])

s3 <- run_or_load(3, run_stage(
  3, b3$aeme, b3$path, s3_adj,
  rbind(carry(s1), carry(s2, except = "light/Kw")),
  targets = vars_bgc,
  sub_regions = list(
    bot_oxy  = list(var = "CHM_oxy", month = c(12, 1, 2), depth_range = c(z - 4, z)),
    surf_oxy = list(var = "CHM_oxy", month = c(12, 1, 2), depth_range = c(0, 2)),
    bot_amm  = list(var = "NIT_amm", month = c(12, 1, 2), depth_range = c(z - 4, z)),
    surf_frp = list(var = "PHS_frp", month = c(12, 1, 2), depth_range = c(0, 2))),
  rebuild = function() fresh_build("s3cal", vars_bgc, use_bgc = TRUE),
  prior_from = s2))

# ---- results ---------------------------------------------------------------

for (s in list(s1, s2, s3)) {
  cat("\nstage", s$stage, "- kept", nrow(s$kept), "parameters, phi",
      paste(signif(s$phi$min, 4), collapse = " -> "), "\n")
  print(s$best[, c("file", "name", "group", "index", "value")],
        row.names = FALSE)
}

# ---- posterior predictive ensemble --------------------------------------
#
# pestpp-ies is an iterative ensemble smoother: its real product is the
# posterior *ensemble*, one parameter vector per realisation. Push that back
# through the model to see the spread of the modelled series against
# observations - a far more honest picture than a single best fit.
#
# To re-enter here in a fresh session, load the stage-3 checkpoint (or see
# staged-calibration-resume.R to rebuild it from the results DB):
if (!exists("s3")) s3 <- readRDS(stage_rds(3))

s3_calib  <- read_calib(ctrl = s3$cal_ctrl, sim_id = s3$cal_id)

plot_pest_ensemble(ctrl = s3_calib, param = s3_calib$parameter_metadata)

# One runnable `param` set per posterior realisation. Frozen stage-1/2
# parameters are carried through at their fixed values, so every set is
# complete.
post_sets <- pest_posterior_params(s3_calib)
print(post_sets)

# Run them. run_aeme_ensemble() takes the list straight through its
# `param_sets` argument (skipping the min/max sampling) and stores every
# member's output on the returned object.
b3_post  <- fresh_build("s3post", vars_bgc, use_bgc = TRUE)
aeme_ens <- run_aeme_ensemble(aeme = b3_post$aeme, model = MODEL,
                              path = b3_post$path, param_sets = post_sets,
                              parallel = TRUE, ncore = NCORE)
# `parallel = FALSE` is the fallback if your installed aemetools predates the
# make_temp_dir() output-directory fix (GLM members fail to run otherwise).

# Collapse the ensemble ONCE. ensemble_summary() loops the members through
# AEME::get_var() a single time and returns the per-date mean / sd / quantile
# bands, the per-member frame, and the depth-aligned observations. Every plot
# below - and the CSV - reuses it instead of re-extracting per call. Depths
# are ignored for the 1-D variables (HYD_thmcln, CHM_oxyepi).
POST_VARS <- c("CHM_oxy", "NIT_amm", "PHS_frp", "HYD_thmcln", "LKE_lvlwtr", "HYD_temp")
post_summary <- ensemble_summary(aeme_ens, model = MODEL, vars_sim = POST_VARS,
                                 depths = c(0, 1, z-2))
print(post_summary)

plot_ensemble(post_summary, var_sim = "CHM_oxy") /
plot_ensemble(post_summary, var_sim = "NIT_amm") /
plot_ensemble(post_summary, var_sim = "PHS_frp")

plot_ensemble(post_summary, var_sim = "LKE_lvlwtr") /
plot_ensemble(post_summary, var_sim = "HYD_temp")   

# The bands as a plain table - to archive, or to diff one run against another.
utils::write.csv(as.data.frame(post_summary),
                 file.path(ROOT, "s3post_bands.csv"), row.names = FALSE)

# Which parameters the data actually constrained (prior -> posterior
# variance reduction):
pest_param_summary(
  s3_calib,
  param = add_name_full(rbind(s3$kept[, PCOLS], carry(s1)[, PCOLS],
                              carry(s2, except = "light/Kw")[, PCOLS])))

plot_pest_phi(s3_calib)

# The prior ensemble, for a prior-vs-posterior band:
prior_sets <- pest_posterior_params(s3_calib, iteration = 0)

# A best-fit subset instead of the full posterior:
#   best <- update_param(s3_calib, param = s3_adj, quantile_threshold = 0.1)
