# Resume a staged calibration at the posterior-predictive-ensemble step
# ============================================================================
#
# Use this when the staged calibration (staged-calibration.R) finished all
# three pestpp-ies stages but the R session was lost before the posterior
# ensemble was run - or that step errored. It re-runs NO calibration: it
# reloads stage 3 from the results database and the kept PEST++ run
# directory, extracts the posterior parameter sets, and pushes them through
# the model.
#
# RUN THIS FROM THE SAME WORKING DIRECTORY as the original script - `ROOT`
# and the control's `file_dir` are relative paths.
#
# What must still be on disk (kept by default, `create_pest_control(keep_files
# = TRUE)`):
#   <ROOT>/s3cal/calib_sa/results.db
#   <ROOT>/s3cal/LID50270_<lake>/pest_s3/<model>/     (the .pst, aeme.<n>.par.csv, ...)

library(AEME)
library(aemetools)

# ---- constants: MUST match the run you are resuming -----------------------
# (copied from staged-calibration.R - keep in sync)

ROOT     <- file.path("staged-calibration")
START    <- "2016-07-01"
STOP     <- "2022-03-24"
SPIN_UP  <- 365 * 3
MODEL    <- "glm_aed"
NCORE    <- max(1L, floor(0.85 * parallel::detectCores()))
vars_bgc <- c("CHM_oxy", "NIT_amm", "PHS_frp", "PHY_tchla")

aeme0 <- readRDS(system.file("extdata/LID50270_Rototoa.rds",
                             package = "aemetools"))
aeme0 <- AEME::set_time(aeme0, start = START, stop = STOP, spin_up = SPIN_UP)

fresh_build <- function(tag, vars_sim, use_bgc) {
  p <- file.path(ROOT, tag)
  unlink(p, recursive = TRUE)
  dir.create(p, recursive = TRUE, showWarnings = FALSE)
  mc <- AEME::set_vars_sim(AEME::get_model_controls(use_bgc = use_bgc),
                           vars_sim = vars_sim)
  a <- AEME::build_aeme(path = p, aeme = aeme0, model = MODEL,
                        model_controls = mc, ext_elev = 5, use_bgc = use_bgc)
  a <- AEME::run_aeme(aeme = a, model = MODEL, path = p)
  list(aeme = a, path = p)
}

# ---- 1. rebuild stage 3's control ----------------------------------------
# Only `file_dir` (where results.db lives) matters for reading; the solver
# knobs and localizer are irrelevant to a read.
cal_ctrl <- create_pest_control(
  exe = "pestpp-ies", file_dir = file.path(ROOT, "s3cal", "calib_sa"))

# ---- 2. the sim id -----------------------------------------------------
# Take it from your console log ("Writing output ... sim ID: ...") or read it
# back from the database:
SIM_ID <- read_calib(ctrl = cal_ctrl)$simulation_metadata$sim_id[[1]]
message("resuming sim_id ", SIM_ID)

# ---- 3. reload the calibration + posterior parameter sets --------------
s3_calib <- read_calib(ctrl = cal_ctrl, sim_id = SIM_ID)
stopifnot(!is.na(s3_calib$calibration_metadata$pest_dir[[1]]),
          dir.exists(s3_calib$calibration_metadata$pest_dir[[1]]))

# One runnable `param` set per posterior realisation. Frozen stage-1/2
# parameters (value == min == max in parameter_metadata) are carried through.
post_sets <- pest_posterior_params(s3_calib)
print(post_sets)

# ---- 4. run the ensemble ---------------------------------------------
b3_post <- fresh_build("s3post", vars_bgc, use_bgc = TRUE)
z <- AEME::input(b3_post$aeme)$init_depth

aeme_ens <- run_aeme_ensemble(aeme = b3_post$aeme, model = MODEL,
                              path = b3_post$path, param_sets = post_sets,
                              parallel = TRUE, ncore = NCORE)
# If your installed aemetools predates the make_temp_dir() output-directory
# fix, GLM members fail under `parallel = TRUE`; use `parallel = FALSE`
# (slower, but runs in the real build directory).

# ---- 5. summarise + plot ------------------------------------------
# ensemble_summary() runs the per-member AEME::get_var() extraction once;
# the plots and the CSV below all read from it.
post_summary <- ensemble_summary(aeme_ens, model = MODEL,
                                 vars_sim = c("CHM_oxy", "NIT_amm", "PHS_frp"),
                                 depths = z - 2)
print(post_summary)

plot_ensemble(post_summary, var_sim = "CHM_oxy", depth = z - 2)
plot_ensemble(post_summary, var_sim = "NIT_amm", depth = z - 2)
utils::write.csv(as.data.frame(post_summary),
                 file.path(ROOT, "s3post_bands.csv"), row.names = FALSE)

# The prior ensemble, for a prior-vs-posterior band:
#   prior_sets <- pest_posterior_params(s3_calib, iteration = 0)

# Which parameters the data constrained (prior -> posterior variance
# reduction). pest_param_summary() needs `name_full` on the template:
#   p <- s3_calib$parameter_metadata
#   p$name_full <- encode_param(p$group, p$name, p$index)
#   pest_param_summary(s3_calib, param = p)
