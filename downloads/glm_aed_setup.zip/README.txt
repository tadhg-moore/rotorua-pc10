Lake Rotorua GLM-AED baseline set-up (calibrated, alum on)

Exported: 2026-11-12 14:53 NZDT by mooret (git b201aed)
Simulation: 1976-01-01 to 2025-12-31 (540-day spin-up; output used from 1977-06-24)
Forcing: bias-corrected ERA5 1976-2025, 2026 PC10 loads (McBride, Limnotrack/BoPRC; noalum_storm_central, old silica constant), alum dosing, outflow held at 6.06 m3/s
Executable: GLM:          limnotrack/GLM@main (2bf1a65b9e4a3eee19f279fbc68d08f5db9bfbf0); libaed-water: limnotrack/libaed-water@v3.0.1 (b11f928f48f378ff6890323bcdcc4562d1589c2d)

Contents: glm4.nml, plots.nml, aed/ (AED namelist and parameter csv files), bcs/ (meteo_glm.csv, inflow_*.csv, outflow_wbal.csv),
parameters.csv (calibrated parameters in AEME format, already applied in the namelists/csv files here).
Run: put the GLM-AED executable (alum build, see above) next to glm4.nml and run `glm.exe glm4.nml`; output goes to output/.
Inflow concentrations are in GLM-AED units (mmol/m3), flows in m3/s.
